export * from './cadastrar-pf.component';
