export * from './cadastrar-pj';
export * from './cadastro-pj.component';
