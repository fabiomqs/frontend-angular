export * from './atualizacao.component';
