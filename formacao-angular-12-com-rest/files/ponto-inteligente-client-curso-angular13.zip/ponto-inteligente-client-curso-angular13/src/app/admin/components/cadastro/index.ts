export * from './cadastro.component';
