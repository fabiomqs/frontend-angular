export * from './tipo.pipe';
export * from './data.pipe';
